extends RefCounted
## Outlaw's authoritative combo state. Presentation never grants hits or charges.
const ROLL_SECONDS := .55
const ROLL_DISTANCE := 6.0
const BACKFLIP_SPEED := 12.0
const COIN_SECONDS := 1.8
const COIN_SPEED := 5.0
const SHOTS := 3
const MAX_STACKS := 3
const SIGHT_RANGE := 18.0
const MOBILE_KINDS := ["defense_detonation", "deadeye"]

static func can_cast_moving(actor, spell: Dictionary) -> bool:
	return actor.champion == "Outlaw" and (spell.kind in MOBILE_KINDS or spell.kind == "severe")

static func initialize(actor) -> void:
	actor.identity.merge({"defense_detonation": 0, "severe_bleeds": {}, "backflip_active": false,
		"backflip_combo": false, "backflip_elapsed": 0.0, "roll_left": 0.0, "roll_direction": Vector3.ZERO,
		"roll_distance": 0.0, "instant_severe": 0.0,
		"coin_left": 0.0, "coin_origin": Vector3.ZERO, "coin_direction": Vector3.FORWARD,
		"coin_position": Vector3.ZERO, "outlaw_channel": {}, "outlaw_action": "", "outlaw_action_serial": 0}, true)

static func backflip_airborne(a) -> bool:
	return a.identity.get("backflip_active", false) and (not a.is_on_floor() or a.velocity.y > .1)

static func mobile_cast(a) -> bool:
	return a.champion == "Outlaw" and a.casting >= 0 and a.kit[a.casting].kind in MOBILE_KINDS

static func deadeye_cast(a) -> bool:
	return mobile_cast(a) and a.kit[a.casting].kind == "deadeye"

static func unkickable(a) -> bool:
	return a.champion == "Outlaw" and a.casting >= 0 and a.kit[a.casting].kind in ["defense_detonation", "severe", "deadeye"]

static func raw_los(game, from: Vector3, to: Vector3) -> bool:
	return game.get_world_3d().direct_space_state.intersect_ray(PhysicsRayQueryParameters3D.create(from, to, 1)).is_empty()

static func trickshot_mode(game, a, b) -> String:
	if a.identity.coin_left > 0:
		var coin: Vector3 = a.identity.coin_position
		if coin.distance_to(b.position + Vector3.UP) <= SIGHT_RANGE and raw_los(game, a.position + Vector3.UP, coin) and raw_los(game, coin, b.position + Vector3.UP):
			return "coin"
	if a.identity.backflip_combo and backflip_airborne(a) and game.has_los(a, b):
		return "backflip"
	return ""

static func validate(game, a, spell: Dictionary, b) -> String:
	if a.champion != "Outlaw": return ""
	if spell.kind == "trickshot":
		if not ((a.identity.backflip_combo and backflip_airborne(a)) or a.identity.coin_left > 0):
			return "Requires Backflip or Coin Toss combo"
		if trickshot_mode(game, a, b).is_empty(): return "Combo shot is blocked by terrain"
	if spell.kind == "defense_detonation" and a.identity.defense_detonation < MAX_STACKS:
		return "Requires 3 Defense Detonation stacks"
	if spell.kind in ["backflip", "roll", "deadeye"] and not a.is_on_floor():
		return "Land before using " + spell.name
	return ""

static func action(a, name: String) -> void:
	a.identity.outlaw_action = name
	a.identity.outlaw_action_serial += 1

static func begin_channel(game, a, spell: Dictionary, target: int) -> void:
	if spell.kind not in MOBILE_KINDS: return
	var marked: Array = []
	if spell.kind == "deadeye":
		# Acquire all eligible opponents, including those currently behind cover.
		# Visibility is decided only when the windup actually finishes.
		for enemy in game.actors.values():
			if enemy.hp > 0 and enemy.team != a.team and game.may_harm(a, enemy): marked.append(enemy.actor_id)
	else:
		a.identity.defense_detonation = 0
	a.identity.outlaw_channel = {"kind": spell.kind, "target": target, "marked": marked, "shots": 0}
	# Long windups cannot be repeatedly cancelled for free.
	a.cooldowns[a.casting] = spell.cd
	action(a, "aim")

static func hit(game, a, b, damage: float, from: Vector3, tag: String) -> void:
	game.damage(a, b, roundf(damage))
	action(a, "gun" if tag == "ricochet_hit" else tag)
	game.outlaw_effect(a.actor_id, b.actor_id, from, b.position + Vector3.UP, tag)

static func tick_channel(game, a, delta: float) -> void:
	if not mobile_cast(a):
		a.identity.outlaw_channel.clear()
		return
	var spell: Dictionary = a.kit[a.casting]
	var channel: Dictionary = a.identity.outlaw_channel
	if channel.is_empty():
		a.casting = -1
		return
	a.cast_left = maxf(0, a.cast_left - delta)
	if spell.kind == "defense_detonation":
		var elapsed: float = spell.cast - a.cast_left
		while channel.shots < SHOTS and elapsed + .00001 >= channel.shots + 1:
			channel.shots += 1
			var target = game.actors.get(channel.target)
			if target != null and target.hp > 0 and target.team != a.team and game.may_harm(a, target) and a.position.distance_to(target.position) <= SIGHT_RANGE and game.has_los(a, target):
				hit(game, a, target, target.MAX_HEALTH * .1, a.position + Vector3.UP, "gun")
	else:
		if a.cast_left <= 0:
			for id in channel.marked:
				var target = game.actors.get(id)
				if target != null and target.hp > 0 and target.team != a.team and game.may_harm(a, target) and a.position.distance_to(target.position) <= SIGHT_RANGE and game.has_los(a, target):
					hit(game, a, target, target.MAX_HEALTH * .4, a.position + Vector3.UP, "gun")
	if a.cast_left <= 0:
		a.casting = -1
		a.identity.outlaw_channel.clear()

static func resolve(game, a, spell: Dictionary, b, camera_yaw: Variant = null) -> bool:
	if a.champion != "Outlaw": return false
	match spell.kind:
		"starshot": hit(game, a, b, spell.power, a.position + Vector3.UP, "gun")
		"severe":
			a.identity.instant_severe = 0.0
			hit(game, a, b, b.hp * .15, a.position + Vector3.UP, "knife")
			if b.hp > 0 and game.may_harm(a, b):
				var previous: Dictionary = b.identity.severe_bleeds.get(a.actor_id, {})
				b.identity.severe_bleeds[a.actor_id] = {"left": 5.0, "tick": previous.get("tick", 1.0)}
		"roll":
			a.identity.roll_left = ROLL_SECONDS
			a.identity.roll_distance = 0.0
			a.identity.roll_direction = game.BlinkCharges.direction(a, camera_yaw)
			a.motion_revision += 1
			action(a, "roll")
		"backflip":
			a.identity.backflip_active = true
			a.identity.backflip_combo = true
			a.identity.backflip_elapsed = 0.0
			var backward: Vector3 = a.basis.z * 3.0
			a.velocity = Vector3(backward.x, BACKFLIP_SPEED, backward.z)
			# Leave cached ground contact before the next normal movement sample.
			a.move_and_collide(Vector3.UP * .04)
			a.motion_revision += 1
			action(a, "backflip")
		"coin_toss":
			a.identity.coin_left = COIN_SECONDS
			a.identity.coin_origin = a.position + Vector3.UP * 1.15
			a.identity.coin_position = a.identity.coin_origin
			var yaw: float = a.rotation.y if camera_yaw == null else float(camera_yaw)
			a.identity.coin_direction = Basis(Vector3.UP, yaw) * Vector3.FORWARD
			action(a, "coin")
		"trickshot":
			var mode := trickshot_mode(game, a, b)
			if mode.is_empty(): return true
			var from: Vector3 = a.position + Vector3.UP
			if mode == "coin":
				from = a.identity.coin_position
				game.outlaw_effect(a.actor_id, a.actor_id, a.position + Vector3.UP, from, "ricochet")
				a.identity.coin_left = 0.0
			else: a.identity.backflip_combo = false
			var before: float = b.hp
			hit(game, a, b, spell.power, from, "ricochet_hit" if mode == "coin" else "gun")
			if b.hp < before or b.training_dummy:
				a.identity.defense_detonation = mini(MAX_STACKS, a.identity.defense_detonation + 1)
		_:
			return false
	return true

static func tick(game, a, delta: float) -> void:
	game.ClassMechanics.tick_dots(game, a, a.identity.severe_bleeds, delta, 2, 0)
	if a.champion != "Outlaw" or a.hp <= 0: return
	a.identity.instant_severe = maxf(0, a.identity.instant_severe - delta)
	if a.identity.backflip_active:
		a.identity.backflip_elapsed += delta
		if a.is_on_floor() and a.velocity.y <= 0:
			a.identity.backflip_active = false
			a.identity.backflip_combo = false
	if a.identity.coin_left > 0:
		var previous: Vector3 = a.identity.coin_position
		a.identity.coin_left = maxf(0, a.identity.coin_left - delta)
		var t: float = COIN_SECONDS - a.identity.coin_left
		var next: Vector3 = a.identity.coin_origin + a.identity.coin_direction * COIN_SPEED * t + Vector3.UP * (5.4 * t - 3.0 * t * t)
		if not raw_los(game, previous, next): a.identity.coin_left = 0.0
		else: a.identity.coin_position = next
	if not mobile_cast(a): a.identity.outlaw_channel.clear()

static func roll_motion(game, a, delta: float) -> bool:
	if a.identity.get("roll_left", 0.0) <= 0: return false
	if a.stunned > 0 or a.identity.root > 0 or a.identity.hold > 0:
		a.identity.roll_left = 0.0
		return false
	var active: float = minf(delta, a.identity.roll_left)
	var distance: float = ROLL_DISTANCE / ROLL_SECONDS * active
	var before: Vector3 = a.position
	var collision = a.move_and_collide(a.identity.roll_direction * distance)
	a.identity.roll_distance += a.position.distance_to(before)
	a.identity.roll_left = maxf(0, a.identity.roll_left - delta)
	if a.identity.roll_left < .00001: a.identity.roll_left = 0.0
	if collision != null: a.identity.roll_left = 0.0
	if a.identity.roll_left <= 0 and a.identity.roll_distance > .01 and game.authoritative():
		a.identity.instant_severe = 1.0
	a.velocity.x = 0; a.velocity.z = 0
	a.velocity.y -= 20 * delta
	a.move_and_slide()
	a.jump_queued = false; a.jump_buffer = 0
	return true

static func bot(game, a, foe) -> bool:
	if a.identity.defense_detonation >= MAX_STACKS and game.try_spell(a.actor_id, 8, foe.actor_id): return true
	if (a.identity.backflip_combo or a.identity.coin_left > 0) and game.try_spell(a.actor_id, 2, foe.actor_id): return true
	if a.position.distance_to(foe.position) < 3 and game.try_spell(a.actor_id, 1, foe.actor_id): return true
	if a.cooldowns[7] <= 0 and game.try_spell(a.actor_id, 7, -1): return true
	if a.cooldowns[3] <= 0 and a.is_on_floor() and game.try_spell(a.actor_id, 3, -1): return true
	if game.try_spell(a.actor_id, 9, -1): return true
	if game.has_los(a, foe) and a.position.distance_to(foe.position) <= SIGHT_RANGE:
		a.move_input = Vector2.ZERO
	return game.try_spell(a.actor_id, 0, foe.actor_id)
